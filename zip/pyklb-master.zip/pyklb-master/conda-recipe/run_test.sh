cd test
python test_pyklb.py
